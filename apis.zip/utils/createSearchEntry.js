export const createSearchEntry = (id, title, type) => {};
