export const confirmMessage = "Really want to Delete?"

export const languages = [
    {
        name: "English",
        code: "eng"
    },
    {
        name: "Bhasha Indonesia",
        code: "bha"
    },
    {
        name: "Spanish",
        code: "sp"
    },
    {
        name: "French",
        code: "fr"
    },
    {
        name: "Vietnamese",
        code: "vi"
    }
]