export const section_data = {
  mainContent: "main content",
  subContent:
    "<p>\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent in \ninterdum purus. Phasellus erat sem, ornare sed felis non, porta volutpat\n risus. Aenean sodales mattis semper. Etiam eleifend ex ex, eu luctus \naugue porta in. Mauris ut odio ut nunc eleifend elementum. Aliquam \nblandit finibus odio, vel lobortis urna venenatis id. Vivamus orci \nligula, sagittis quis volutpat nec, scelerisque sed risus. Sed gravida \ntortor vitae neque consequat sollicitudin. Nullam bibendum volutpat \nimperdiet. Curabitur vehicula in libero et hendrerit.\n</p>\n<p>\nCras rutrum faucibus massa, eu molestie nisl dapibus eu. Curabitur \nmattis sollicitudin auctor. Quisque dignissim id leo elementum iaculis. \nAliquam erat volutpat. Nulla augue purus, condimentum ac dolor sed, \nultrices varius felis. Nam tincidunt, diam ut sagittis semper, libero \nmassa luctus tortor, non dignissim ante lectus et mauris. Nam blandit \nsed erat vel auctor. Nullam vehicula cursus lacinia. Morbi metus orci, \nefficitur et augue a, aliquet ultrices urna. Proin eget ornare ipsum, \nvel porta justo. Maecenas quam ex, consectetur vitae porta non, mollis \nut tortor.\n</p>\n<p>\nPraesent odio erat, molestie vel velit vel, sollicitudin euismod risus. \nOrci varius natoque penatibus et magnis dis parturient montes, nascetur \nridiculus mus. Nunc luctus consectetur elit ac luctus. Vestibulum \nultricies vestibulum mi eu porttitor. Maecenas sit amet erat sapien. Nam\n semper eget nisi eget mattis. Donec dolor arcu, convallis id risus \nvitae, hendrerit laoreet libero. Quisque commodo nisl magna, eu luctus \nmauris sollicitudin vel. Sed mattis enim sed orci cursus dignissim sed \nnon sapien. Quisque interdum ipsum nec neque aliquam bibendum. Duis in \nposuere quam. Maecenas faucibus tristique neque sed vulputate. Nullam \nmalesuada tristique augue, vel vestibulum ligula. Nam non nisl ut nulla \nmollis placerat.\n</p>\n<p>\nProin in purus sit amet lorem vehicula luctus. Vivamus non vestibulum \nex. Aliquam efficitur mi id pulvinar varius. Suspendisse vulputate dui \nlectus, ut mollis sem varius a. Ut rutrum feugiat nibh vitae aliquet. \nCras lectus est, egestas id tortor eget, dapibus aliquam urna. \nPellentesque sed commodo magna. Vestibulum dignissim augue sed \nconsectetur dignissim. Fusce elit odio, iaculis et nisi ut, mattis \nfacilisis odio. Morbi egestas, orci in vulputate placerat, dolor libero \nposuere massa, nec luctus ligula purus ac lorem.\n</p>\n<p><br></p>",
  title: "Title",
  tools: [
    {
      title: "tool title 1 abc",
      items: [
        {
          title: "tool item title one abc",
          previewLink: "",
          downloadLink: "",
        },
      ],
    },
  ],
};
